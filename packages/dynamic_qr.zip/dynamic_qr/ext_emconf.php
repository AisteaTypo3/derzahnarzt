<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Dynamic QR Codes',
    'description' => 'Erzeugen, verwalten und tracken dynamischer QR-Codes (SVG/PNG) inkl. Middleware-Redirects',
    'category' => 'be',
    'author' => 'Dynamic QR Team',
    'author_email' => 'dev@example.com',
    'state' => 'beta',
    'clearcacheonload' => 1,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '13.0.0-13.9.99',
            'php' => '8.2.0-8.9.99'
        ]
    ],
];
