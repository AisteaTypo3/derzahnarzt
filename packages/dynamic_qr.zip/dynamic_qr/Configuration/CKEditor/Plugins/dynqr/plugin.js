(function() {
    if (typeof CKEDITOR === 'undefined') return;
    CKEDITOR.plugins.add('dynqr', {
        icons: 'qr',
        init: function(editor) {
            editor.addCommand('insertDynamicQr', {
                exec: function(editor) {
                    var slug = prompt('QR Slug eingeben (z.B. flyer-2025):');
                    if (!slug) return;
                    var size = prompt('Größe (px, optional, default 256):', '256') || '256';
                    var img = '<img data-dynqr="'+CKEDITOR.tools.htmlEncode(slug)+'" alt="QR '+CKEDITOR.tools.htmlEncode(slug)+'" width="'+size+'" height="'+size+'" />';
                    editor.insertHtml(img);
                }
            });
            editor.ui.addButton('dynqr', {
                label: 'QR einfügen',
                command: 'insertDynamicQr',
                toolbar: 'insert',
                icon: this.path + 'icons/qr.svg'
            });
        }
    });
})();
