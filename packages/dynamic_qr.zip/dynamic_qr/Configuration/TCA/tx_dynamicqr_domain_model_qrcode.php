<?php

defined('TYPO3') or die();

return [
    'ctrl' => [
        'title' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_db.xlf:tx_dynamicqr_domain_model_qrcode',
        'label' => 'slug',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'delete' => 'deleted',
        'enablecolumns' => [
            'disabled' => 'hidden',
        ],
        'searchFields' => 'slug,target_url',
        'iconfile' => 'EXT:dynamic_qr/Resources/Public/Icons/module-qr.svg',
        'security' => [
            'ignorePageTypeRestriction' => true
        ],
    ],
    'types' => [
        '1' => [
            'showitem' => '
                slug, target_url, enabled,
                --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:options,
                options,
                --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:access,
                hidden
            ',
        ],
    ],
    'columns' => [
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'renderType' => 'checkboxToggle',
            ],
        ],
        'slug' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_db.xlf:field.slug',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim,lower,alphanum_x,unique',
            ],
        ],
        'target_url' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_db.xlf:field.target_url',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputLink',
                'eval' => 'trim,required',
            ],
        ],
        'enabled' => [
            'exclude' => false,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.enabled',
            'config' => [
                'type' => 'check',
                'renderType' => 'checkboxToggle',
                'default' => 1,
            ],
        ],
        'options' => [
            'exclude' => false,
            'label' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_db.xlf:field.options',
            'config' => [
                'type' => 'text',
                'renderType' => 't3editor',
                'format' => 'json',
                'default' => '{"size":256,"ecc":"M","fg":"#000000","bg":"#ffffff","logoPath":""}'
            ],
        ],
    ],
];
