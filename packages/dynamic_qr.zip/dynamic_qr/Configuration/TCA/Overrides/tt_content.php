<?php

defined('TYPO3') or die();

$tempColumns = [
    'tx_dynamicqr_qrcode' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_db.xlf:tt_content.tx_dynamicqr_qrcode',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectSingle',
            'items' => [
                ['-- none --', 0],
            ],
            'foreign_table' => 'tx_dynamicqr_domain_model_qrcode',
            'default' => 0,
        ],
    ],
];

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('tt_content', $tempColumns);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes('tt_content', 'tx_dynamicqr_qrcode', '', 'after:header');
