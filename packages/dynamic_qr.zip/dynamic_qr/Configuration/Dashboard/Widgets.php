<?php

return [
    'widgets' => [
        'dynamicqr-scans-7d' => [
            'title' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_mod.xlf:widget.scans7d',
            'description' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_mod.xlf:widget.scans7d.desc'
        ],
        'dynamicqr-top5-30d' => [
            'title' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_mod.xlf:widget.top5',
            'description' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_mod.xlf:widget.top5.desc'
        ],
    ],
];
