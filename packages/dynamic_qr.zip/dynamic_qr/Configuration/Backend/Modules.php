<?php

return [
    'tools_dynamicqr' => [
        'parent' => 'tools',
        'position' => ['after' => 'systemmaintenancem'],
        'access' => 'user,group',
        'iconIdentifier' => 'module-dynamicqr',
        'path' => '/module/dynamicqr',
        'labels' => 'LLL:EXT:dynamic_qr/Resources/Private/Language/locallang_mod.xlf',
        'routes' => [
            '_default' => [
                'target' => Vendor\DynamicQr\Controller\Backend\QrCodeController::class . '::indexAction',
            ],
            'edit' => [
                'target' => Vendor\DynamicQr\Controller\Backend\QrCodeController::class . '::editAction',
            ],
            'save' => [
                'target' => Vendor\DynamicQr\Controller\Backend\QrCodeController::class . '::saveAction',
            ],
            'export' => [
                'target' => Vendor\DynamicQr\Controller\Backend\QrCodeController::class . '::exportCsvAction',
            ],
            'stats' => [
                'target' => Vendor\DynamicQr\Controller\Backend\QrCodeController::class . '::statsAction',
            ],
        ],
    ],
];
