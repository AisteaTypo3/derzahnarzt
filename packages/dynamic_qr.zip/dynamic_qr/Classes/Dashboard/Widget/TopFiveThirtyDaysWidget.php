<?php

namespace Vendor\DynamicQr\Dashboard\Widget;

class TopFiveThirtyDaysWidget
{
    // Implement with TYPO3 Dashboard API if needed; placeholder to register widget
}
