<?php

namespace Vendor\DynamicQr\Dashboard\Widget;

class ScansSevenDaysWidget
{
    // Implement with TYPO3 Dashboard API if needed; placeholder to register widget
}
