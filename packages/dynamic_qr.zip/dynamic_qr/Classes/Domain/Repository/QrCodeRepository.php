<?php

namespace Vendor\DynamicQr\Domain\Repository;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class QrCodeRepository
{
    private const TABLE = 'tx_dynamicqr_domain_model_qrcode';

    public function findBySlug(string $slug): ?array
    {
        $qb = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable(self::TABLE);
        $row = $qb->select('*')
            ->from(self::TABLE)
            ->where(
                $qb->expr()->eq('slug', $qb->createNamedParameter($slug)),
                $qb->expr()->eq('deleted', 0),
                $qb->expr()->eq('hidden', 0),
                $qb->expr()->eq('enabled', 1)
            )
            ->executeQuery()
            ->fetchAssociative();
        if (!$row) return null;
        $row['options'] = $this->decodeOptions($row['options'] ?? '');
        return $row;
    }

    public function findAll(int $limit = 100, int $offset = 0, string $search = ''): array
    {
        $qb = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable(self::TABLE);
        $qb->select('uid','slug','target_url','enabled','tstamp','crdate','options')
           ->from(self::TABLE)
           ->where(
                $qb->expr()->eq('deleted', 0)
           )
           ->orderBy('tstamp', 'DESC')
           ->setMaxResults($limit)
           ->setFirstResult($offset);
        if ($search !== '') {
            $qb->andWhere(
                $qb->expr()->or(
                    $qb->expr()->like('slug', $qb->createNamedParameter('%'.$search.'%')),
                    $qb->expr()->like('target_url', $qb->createNamedParameter('%'.$search.'%'))
                )
            );
        }
        $rows = $qb->executeQuery()->fetchAllAssociative();
        foreach ($rows as &$r) {
            $r['options'] = $this->decodeOptions($r['options'] ?? '');
        }
        return $rows;
    }

    public function upsert(array $data): int
    {
        $qb = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable(self::TABLE);
        $now = time();
        $dataDb = [
            'pid' => (int)($data['pid'] ?? 0),
            'tstamp' => $now,
            'crdate' => $data['uid'] ? (int)($data['crdate'] ?? $now) : $now,
            'slug' => (string)$data['slug'],
            'target_url' => (string)$data['target_url'],
            'enabled' => (int)($data['enabled'] ?? 1),
            'options' => json_encode($data['options'] ?? []),
        ];
        if (!empty($data['uid'])) {
            $qb->update(self::TABLE)
                ->where($qb->expr()->eq('uid', (int)$data['uid']))
                ->values($dataDb)
                ->executeStatement();
            return (int)$data['uid'];
        }
        $qb->insert(self::TABLE)->values($dataDb)->executeStatement();
        return (int)$qb->getConnection()->lastInsertId(self::TABLE);
    }

    private function decodeOptions(string $json): array
    {
        $opts = json_decode($json ?: '{}', true);
        if (!is_array($opts)) $opts = [];
        $opts = array_merge([
            'size' => 256,
            'ecc' => 'M',
            'fg' => '#000000',
            'bg' => '#ffffff',
            'logoPath' => '',
        ], $opts);
        return $opts;
    }
}
