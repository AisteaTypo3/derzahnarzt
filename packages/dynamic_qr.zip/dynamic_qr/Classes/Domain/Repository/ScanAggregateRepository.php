<?php

namespace Vendor\DynamicQr\Domain\Repository;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class ScanAggregateRepository
{
    private const TABLE = 'tx_dynamicqr_domain_model_scanaggregate';

    public function inc(string $day, int $qrcodeUid): void
    {
        $conn = GeneralUtility::makeInstance(ConnectionPool::class)->getConnectionForTable(self::TABLE);
        $existing = $conn->select(['uid','scans'], self::TABLE, ['day' => $day, 'qrcode' => $qrcodeUid])->fetchAssociative();
        if ($existing) {
            $conn->update(self::TABLE, ['scans' => $existing['scans'] + 1], ['uid' => $existing['uid']]);
        } else {
            $conn->insert(self::TABLE, ['pid' => 0, 'qrcode' => $qrcodeUid, 'day' => $day, 'scans' => 1]);
        }
    }

    public function sumForPeriod(int $qrcodeUid, int $days): int
    {
        $qb = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable(self::TABLE);
        $from = (new \DateTimeImmutable('-'.$days.' days'))->format('Y-m-d');
        $sum = (int)$qb->selectLiteral('COALESCE(SUM(scans),0) AS s')
            ->from(self::TABLE)
            ->where(
                $qb->expr()->eq('qrcode', $qb->createNamedParameter($qrcodeUid)),
                $qb->expr()->gte('day', $qb->createNamedParameter($from))
            )
            ->executeQuery()
            ->fetchOne();
        return $sum;
    }

    public function top(int $days, int $limit = 5): array
    {
        $qb = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable(self::TABLE);
        $from = (new \DateTimeImmutable('-'.$days.' days'))->format('Y-m-d');
        return $qb->select('qrcode')
            ->addSelectLiteral('SUM(scans) AS scans')
            ->from(self::TABLE)
            ->where($qb->expr()->gte('day', $qb->createNamedParameter($from)))
            ->groupBy('qrcode')
            ->orderBy('scans', 'DESC')
            ->setMaxResults($limit)
            ->executeQuery()
            ->fetchAllAssociative();
    }
}
