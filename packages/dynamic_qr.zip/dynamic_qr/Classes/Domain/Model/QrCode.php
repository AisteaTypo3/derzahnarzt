<?php

namespace Vendor\DynamicQr\Domain\Model;

class QrCode
{
    public int $uid = 0;
    public int $pid = 0;
    public string $slug = '';
    public string $targetUrl = '';
    public bool $enabled = true;
    /** @var array<string,mixed> */
    public array $options = [];
}
