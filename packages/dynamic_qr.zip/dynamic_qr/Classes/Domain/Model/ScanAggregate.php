<?php

namespace Vendor\DynamicQr\Domain\Model;

class ScanAggregate
{
    public int $uid = 0;
    public int $pid = 0;
    public int $qrcode = 0;
    public string $day = ''; // YYYY-MM-DD
    public int $scans = 0;
}
