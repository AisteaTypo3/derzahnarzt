<?php

namespace Vendor\DynamicQr\Service;

use Vendor\DynamicQr\Domain\Repository\ScanAggregateRepository;
use Vendor\DynamicQr\Domain\Repository\QrCodeRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class TrackingService
{
    public function __construct(
        private readonly ScanAggregateRepository $scanRepo,
        private readonly QrCodeRepository $qrRepo
    ){}

    public function countScanBySlug(string $slug): void
    {
        $row = $this->qrRepo->findBySlug($slug);
        if (!$row) return;
        $today = (new \DateTimeImmutable('today'))->format('Y-m-d');
        $this->scanRepo->inc($today, (int)$row['uid']);
    }
}
