<?php

namespace Vendor\DynamicQr\Service;

use TYPO3\CMS\Core\Cache\CacheManager;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use Vendor\DynamicQr\Domain\Repository\QrCodeRepository;

class RedirectCacheService
{
    private \TYPO3\CMS\Core\Cache\Frontend\FrontendInterface $cache;

    public function __construct(CacheManager $cacheManager)
    {
        $this->cache = $cacheManager->getCache('dynamicqr_redirect');
    }

    public function getTargetUrlBySlug(string $slug): ?string
    {
        $key = 'slug:' . $slug;
        $hit = $this->cache->get($key);
        if ($hit !== false) {
            return $hit ?: null;
        }
        /** @var QrCodeRepository $repo */
        $repo = GeneralUtility::makeInstance(QrCodeRepository::class);
        $row = $repo->findBySlug($slug);
        $target = $row['target_url'] ?? null;
        $this->cache->set($key, $target ?? '', [], 86400);
        return $target;
        }
}
