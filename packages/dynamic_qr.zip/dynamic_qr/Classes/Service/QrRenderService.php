<?php

namespace Vendor\DynamicQr\Service;

use Endroid\QrCode\QrCode as EndroidQr;
use Endroid\QrCode\Writer\SvgWriter;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Logo\Logo;
use TYPO3\CMS\Core\Site\SiteFinder;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class QrRenderService
{
    private \TYPO3\CMS\Core\Cache\Frontend\FrontendInterface $cache;

    public function __construct(\TYPO3\CMS\Core\Cache\CacheManager $cacheManager)
    {
        $this->cache = $cacheManager->getCache('dynamicqr_image');
    }

    public function absoluteUrlForSlug(string $slug): string
    {
        $base = null;

        if (isset($GLOBALS['TYPO3_REQUEST'])) {
            $site = $GLOBALS['TYPO3_REQUEST']->getAttribute('site');
            if ($site) {
                $base = (string)$site->getBase();
            }
        }

        if (!$base) {
            $finder = GeneralUtility::makeInstance(SiteFinder::class);
            $sites = $finder->getAllSites();
            if (!empty($sites)) {
                $first = reset($sites);
                $base = (string)$first->getBase();
            }
        }

        if (!$base) {
            $host = $_SERVER['HTTP_HOST'] ?? 'example.com';
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $base = $scheme . '://' . $host . '/';
        }

        return rtrim($base, '/') . '/q/' . ltrim($slug, '/');
    }

    private function resolveEcc(string $ecc)
    {
        $letter = strtoupper($ecc);
        $map = [
            'L' => 'Low',
            'M' => 'Medium',
            'Q' => 'Quartile',
            'H' => 'High',
        ];
        $name = $map[$letter] ?? 'Medium';

        $className = '\\Endroid\\QrCode\\ErrorCorrectionLevel\\ErrorCorrectionLevel' . $name;
        if (class_exists($className)) {
            return new $className();
        }

        $enumClass = '\\Endroid\\QrCode\\ErrorCorrectionLevel\\ErrorCorrectionLevel';
        if (class_exists($enumClass)) {
            if (defined($enumClass . '::' . strtoupper($name))) {
                return constant($enumClass . '::' . strtoupper($name));
            }
            if (defined($enumClass . '::' . $name)) {
                return constant($enumClass . '::' . $name);
            }
        }

        return null;
    }

    private function hexToColor(string $hex): \Endroid\QrCode\Color\Color
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $r = hexdec(str_repeat($hex[0], 2));
            $g = hexdec(str_repeat($hex[1], 2));
            $b = hexdec(str_repeat($hex[2], 2));
        } else {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        return new \Endroid\QrCode\Color\Color($r, $g, $b);
    }


    /**
     * @param array{size?:int,ecc?:string,fg?:string,bg?:string,logoPath?:string} $opts
     * @return string SVG XML or PNG binary string
     */
    public function render(string $slug, array $opts = [], string $format = 'svg'): string
    {
        $opts = array_merge(['size'=>256,'ecc'=>'M','fg'=>'#000000','bg'=>'#ffffff','logoPath'=>''], $opts);
        $cacheKey = sha1($slug.'|'.$format.'|'.json_encode($opts));
        $cached = $this->cache->get($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        $content = $this->absoluteUrlForSlug($slug);

        $qr = EndroidQr::create($content);
        $qr = $qr->setSize((int)$opts['size']);

        $eccObj = $this->resolveEcc((string)$opts['ecc']);
        if ($eccObj !== null) {
            $qr = $qr->setErrorCorrectionLevel($eccObj);
        }

        $qr = $qr->setForegroundColor($this->hexToColor((string)$opts['fg']));
        $qr = $qr->setBackgroundColor($this->hexToColor((string)$opts['bg']));

        if (!empty($opts['logoPath'])) {
            $qr = $qr->setLogo(
                Logo::fromPath((string)$opts['logoPath'])->setResizeToWidth((int)round(((int)$opts['size']) * 0.2))
            );
        }

        $writer = ($format === 'png') ? new PngWriter() : new SvgWriter();
        $data = $writer->write($qr)->getString();
        $this->cache->set($cacheKey, $data, [], 86400);
        return $data;
    }
}
