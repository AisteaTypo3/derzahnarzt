<?php

namespace Vendor\DynamicQr\Middleware;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Message\ResponseInterface;
use TYPO3\CMS\Core\Http\Response;
use Vendor\DynamicQr\Service\RedirectCacheService;
use Vendor\DynamicQr\Service\TrackingService;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final class RedirectMiddleware implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $path = ltrim((string)$request->getUri()->getPath(), '/');
        if (!str_starts_with($path, 'q/')) {
            return $handler->handle($request);
        }

        $slug = substr($path, 2);
        /** @var RedirectCacheService $cache */
        $cache = GeneralUtility::makeInstance(RedirectCacheService::class);
        $target = $cache->getTargetUrlBySlug($slug);

        if (!$target) {
            return (new Response())->withStatus(404);
        }

        // Optional anonymized tracking
        /** @var TrackingService $tracking */
        $tracking = GeneralUtility::makeInstance(TrackingService::class);
        $tracking->countScanBySlug($slug);

        return (new Response())
            ->withStatus(302)
            ->withHeader('Location', $target)
            ->withHeader('Cache-Control', 'no-store');
    }
}
