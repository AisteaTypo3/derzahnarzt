<?php

namespace Vendor\DynamicQr\ViewHelpers;

use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;
use Vendor\DynamicQr\Service\QrRenderService;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final class QrViewHelper extends AbstractViewHelper
{
    protected $escapeOutput = false;

    public function initializeArguments(): void
    {
        $this->registerArgument('slug', 'string', true);
        $this->registerArgument('size', 'int', false, 256);
        $this->registerArgument('ecc', 'string', false, 'M');
        $this->registerArgument('format', 'string', false, 'svg');
        $this->registerArgument('fg', 'string', false, '#000000');
        $this->registerArgument('bg', 'string', false, '#ffffff');
        $this->registerArgument('logoPath', 'string', false, '');
        $this->registerArgument('imgClass', 'string', false, '');
        $this->registerArgument('alt', 'string', false, 'QR');
    }

    public function render(): string
    {
        /** @var QrRenderService $svc */
        $svc = GeneralUtility::makeInstance(QrRenderService::class);
        $svgOrPng = $svc->render(
            (string)$this->arguments['slug'],
            [
                'size' => (int)$this->arguments['size'],
                'ecc'  => (string)$this->arguments['ecc'],
                'fg'   => (string)$this->arguments['fg'],
                'bg'   => (string)$this->arguments['bg'],
                'logoPath' => (string)$this->arguments['logoPath'],
            ],
            (string)$this->arguments['format']
        );

        $format = $this->arguments['format'];
        $src = $format === 'png'
            ? 'data:image/png;base64,' . base64_encode($svgOrPng)
            : 'data:image/svg+xml;base64,' . base64_encode($svgOrPng);

        $class = htmlspecialchars((string)$this->arguments['imgClass']);
        $alt = htmlspecialchars((string)$this->arguments['alt']);
        $size = (int)$this->arguments['size'];

        return sprintf('<img class="%s" alt="%s" src="%s" width="%d" height="%d"/>',
            $class, $alt, $src, $size, $size
        );
    }
}
