<?php

namespace Vendor\DynamicQr\Controller\Backend;

use Psr\Http\Message\ResponseInterface;
use TYPO3\CMS\Backend\Template\ModuleTemplateFactory;
use TYPO3\CMS\Core\Http\Response;
use TYPO3\CMS\Core\Http\ServerRequest;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use Vendor\DynamicQr\Domain\Repository\QrCodeRepository;
use Vendor\DynamicQr\Domain\Repository\ScanAggregateRepository;
use Vendor\DynamicQr\Service\QrRenderService;

class QrCodeController
{
    private function moduleTemplateFactory(): ModuleTemplateFactory
    {
        return GeneralUtility::makeInstance(ModuleTemplateFactory::class);
    }
    private function repo(): QrCodeRepository
    {
        return GeneralUtility::makeInstance(QrCodeRepository::class);
    }
    private function scanRepo(): ScanAggregateRepository
    {
        return GeneralUtility::makeInstance(ScanAggregateRepository::class);
    }
    private function qrService(): QrRenderService
    {
        return GeneralUtility::makeInstance(QrRenderService::class);
    }

    public function indexAction(ServerRequest $request): ResponseInterface
    {
        $query = (string)($request->getQueryParams()['q'] ?? '');
        $rows = $this->repo()->findAll(100, 0, $query);

        $html = $this->render('Index', ['rows' => $rows, 'q' => $query]);
        $response = new Response();
        $response->getBody()->write($html);
        return $response;
    }

    public function editAction(ServerRequest $request): ResponseInterface
    {
        $uid = (int)($request->getQueryParams()['uid'] ?? 0);
        $row = null;
        $html = $this->render('Edit', ['uid'=>$uid,'row'=>$row]);
        $response = new Response();
        $response->getBody()->write($html);
        return $response;
    }

    public function saveAction(ServerRequest $request): ResponseInterface
    {
        $data = $request->getParsedBody() ?: [];
        $data['options'] = json_decode((string)($data['options'] ?? '{}'), true) ?: [];
        $uid = $this->repo()->upsert($data);
        $res = new Response();
        $res->getBody()->write('<script>location.href="?route=/module/dynamicqr";</script>');
        return $res;
    }

    public function exportCsvAction(ServerRequest $request): ResponseInterface
    {
        $rows = $this->repo()->findAll(10000, 0, '');

        $fh = fopen('php://temp', 'w+');
        fputcsv($fh, ['slug','target_url','enabled'], ';');
        foreach ($rows as $r) {
            fputcsv($fh, [$r['slug'],$r['target_url'],$r['enabled']], ';');
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        $response = new Response();
        $response->getBody()->write($csv);
        return $response
            ->withHeader('Content-Type','text/csv; charset=utf-8')
            ->withHeader('Content-Disposition','attachment; filename="qr-export.csv"');
    }

    private function render(string $template, array $vars): string
    {
        extract($vars);
        if ($template === 'Index') {
            ob_start(); ?>
            <div class="container">
                <h1>Dynamic QR</h1>
                <form method="get">
                    <input type="hidden" name="route" value="/module/dynamicqr">
                    <input type="text" name="q" value="<?=htmlspecialchars($q)?>" placeholder="Suche..." />
                    <button type="submit" class="btn btn-default">Suchen</button>
                    <a class="btn btn-default" href="?route=/module/dynamicqr&action=export">CSV Export</a>
                </form>
                <table class="table table-striped">
                    <thead><tr><th>Slug</th><th>Ziel</th><th>Status</th><th>Preview</th></tr></thead>
                    <tbody>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?=htmlspecialchars($r['slug'])?></td>
                            <td style="max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?=htmlspecialchars($r['target_url'])?></td>
                            <td><?= $r['enabled'] ? '✓' : '–' ?></td>
                            <td>
                                <?php
                                  $svg = base64_encode($this->qrService()->render($r['slug'], $r['options'], 'svg'));
                                  echo '<img alt="QR" width="96" height="96" src="data:image/svg+xml;base64,'.$svg.'" />';
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php
            return (string)ob_get_clean();
        }
        if ($template === 'Edit') {
            ob_start(); ?>
            <div class="container">
                <h1>QR bearbeiten / neu</h1>
                <form method="post" action="?route=/module/dynamicqr&action=save">
                    <input type="hidden" name="uid" value="<?= (int)($row['uid'] ?? 0) ?>">
                    <div>
                        <label>Slug</label>
                        <input type="text" name="slug" required>
                    </div>
                    <div>
                        <label>Ziel-URL</label>
                        <input type="text" name="target_url" required>
                    </div>
                    <div>
                        <label>Enabled</label>
                        <input type="checkbox" name="enabled" value="1" checked>
                    </div>
                    <div>
                        <label>Optionen (JSON)</label>
                        <textarea name="options" rows="6">{"size":256,"ecc":"M","fg":"#000000","bg":"#ffffff","logoPath":""}</textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Speichern</button>
                </form>
            </div>
            <?php
            return (string)ob_get_clean();
        }
        return '';
    }
}
