<?php

namespace Vendor\DynamicQr\Controller;

use Psr\Http\Message\ResponseInterface;
use TYPO3\CMS\Core\Http\Response;
use TYPO3\CMS\Core\Http\ServerRequest;
use Vendor\DynamicQr\Service\QrRenderService;

class PublicController
{
    public function __construct(private readonly QrRenderService $svc){}

    public function render(ServerRequest $request): ResponseInterface
    {
        $p = $request->getQueryParams();
        $slug = (string)($p['slug'] ?? '');
        $format = in_array(($p['format'] ?? 'svg'), ['svg','png'], true) ? (string)$p['format'] : 'svg';
        $opts = [
            'size' => (int)($p['size'] ?? 256),
            'ecc' => (string)($p['ecc'] ?? 'M'),
            'fg' => (string)($p['fg'] ?? '#000000'),
            'bg' => (string)($p['bg'] ?? '#ffffff'),
            'logoPath' => (string)($p['logoPath'] ?? ''),
        ];
        $binary = $this->svc->render($slug, $opts, $format);
        $res = new Response();
        $res->getBody()->write($binary);
        $ctype = $format === 'png' ? 'image/png' : 'image/svg+xml';
        return $res
            ->withHeader('Content-Type', $ctype)
            ->withHeader('Cache-Control', 'public, max-age=31536000')
            ->withHeader('ETag', sha1($binary));
    }
}
