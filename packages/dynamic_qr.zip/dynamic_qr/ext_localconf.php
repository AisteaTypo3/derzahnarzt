<?php

defined('TYPO3') or die();

use Vendor\DynamicQr\Middleware\RedirectMiddleware;
use TYPO3\CMS\Core\Utility\GeneralUtility;

// PSR-15 Middleware registration (early in stack)
$GLOBALS['TYPO3_CONF_VARS']['SYS']['middleware']['dynamicqr-redirect'] = [
    'target' => RedirectMiddleware::class,
    'after'  => ['typo3/cms-frontend/tsfe'],
    'before' => ['typo3/cms-frontend/authentication'],
];

// Caches
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['dynamicqr_redirect'] ??= [];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['dynamicqr_image'] ??= [];

// Register Fluid namespace
$GLOBALS['TYPO3_CONF_VARS']['SYS']['fluid']['namespaces']['dynqr'] = ['Vendor\\DynamicQr\\ViewHelpers'];

// Register Dashboard widgets
$GLOBALS['TYPO3_CONF_VARS']['BE']['dashboard']['widgets'] ??= [];
$GLOBALS['TYPO3_CONF_VARS']['BE']['dashboard']['widgets']['dynamicqr-scans-7d'] = [
    'class' => Vendor\DynamicQr\Dashboard\Widget\ScansSevenDaysWidget::class,
    'groupNames' => ['dynamicqr'],
];
$GLOBALS['TYPO3_CONF_VARS']['BE']['dashboard']['widgets']['dynamicqr-top5-30d'] = [
    'class' => Vendor\DynamicQr\Dashboard\Widget\TopFiveThirtyDaysWidget::class,
    'groupNames' => ['dynamicqr'],
];

// Public render route (optional controller route signature)
\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
    'DynamicQr',
    'Render',
    [Vendor\DynamicQr\Controller\PublicController::class => 'render'],
    [Vendor\DynamicQr\Controller\PublicController::class => 'render']
);
