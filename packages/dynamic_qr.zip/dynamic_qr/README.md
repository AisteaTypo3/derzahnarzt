# Dynamic QR (TYPO3 v13)

TYPO3 v13 Extension for dynamic QR codes with redirect middleware, SVG/PNG rendering, backend management, and optional anonymous tracking.

## Install

```
composer req vendor/dynamic-qr:* @dev
# or copy `dynamic_qr/` into typo3conf/ext and activate in Extension Manager
```

## Features
- Dynamic redirect: `/q/{slug}` → target URL (changeable later)
- QR generation with endroid/qr-code (SVG/PNG), size/ECC/colors/logo
- Backend module (list, search, CSV export)
- Fluid ViewHelper `<dynqr:qr .../>`
- TCA field on `tt_content`
- Optional scan aggregation (no IP/UA)

## Usage

- Create a record in **QR Code** table (SysFolder recommended). Set slug and target URL.
- Insert into Fluid:  
  `{namespace dynqr=Vendor\DynamicQr\ViewHelpers}`  
  `<dynqr:qr slug="flyer-2025" size="320" ecc="Q" format="svg" />`

- Public image endpoint (optional): `/index.php?eID=dynamicqr_render&slug=...` (via PublicController route).

## Notes
- Middleware handles `/q/{slug}` redirects early; cache hit keeps latency low.
- Tracking is anonymized: only daily counters.
