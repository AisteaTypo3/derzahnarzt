CREATE TABLE tx_dynamicqr_domain_model_qrcode (
  uid INT AUTO_INCREMENT PRIMARY KEY,
  pid INT DEFAULT 0 NOT NULL,
  tstamp INT DEFAULT 0 NOT NULL,
  crdate INT DEFAULT 0 NOT NULL,
  cruser_id INT DEFAULT 0 NOT NULL,
  deleted TINYINT(1) DEFAULT 0 NOT NULL,
  hidden TINYINT(1) DEFAULT 0 NOT NULL,

  slug VARCHAR(64) NOT NULL,
  target_url TEXT NOT NULL,
  options TEXT NULL,
  enabled TINYINT(1) DEFAULT 1 NOT NULL,

  UNIQUE KEY uq_slug (slug)
);

CREATE TABLE tx_dynamicqr_domain_model_scanaggregate (
  uid INT AUTO_INCREMENT PRIMARY KEY,
  pid INT DEFAULT 0 NOT NULL,
  qrcode INT NOT NULL,
  day DATE NOT NULL,
  scans INT DEFAULT 0 NOT NULL,
  UNIQUE KEY uq_qr_day (qrcode, day)
);
