# Dynamic QR Code (TYPO3 v13)

Features:
- Datensatz-Typ **Dynamic QR Code** im Backend
- Live-Vorschau im Datensatz (SVG im Iframe)
- Sicherer SVG-Endpunkt `/dynamic-qrcode/svg?uid=...&h=...` (HMAC)
- Frontend-Plugin *Qrcode* zum Einbinden eines QR-Codes per UID
- Download als SVG

## Installation
1. Ablegen als `typo3conf/ext/dynamic_qrcode` (oder per Composer als Pfad-Repository).
2. `composer require endroid/qr-code:^5.0`
3. Datenbank upgraden (Install Tool / CLI).
4. Backend: Neuen Datensatz **Dynamic QR Code** anlegen.
5. Im Frontend eine Seite mit Inhaltselement *Plugins → Dynamic QR Code: Qrcode* anlegen und die UID setzen (Plugin-Felder).

## Sicherheit
Der SVG-Endpunkt erfordert einen gültigen HMAC, berechnet aus der Datensatz-UID und dem System-EncryptionKey.

## Hinweis
Optionales Logo kann Pfad oder URL sein (der Server muss Zugriff haben).