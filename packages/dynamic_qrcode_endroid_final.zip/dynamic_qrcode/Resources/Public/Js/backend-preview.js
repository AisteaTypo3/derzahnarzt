// Simple QR code generator using minimal vanilla JS (fallback to QRious-like implementation)
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        const previewContainer = document.querySelector('[data-formengine-input-name$="[preview_field]"]');
        if (!previewContainer) return;
        const wrap = document.createElement('div');
        wrap.id = 'dqrc-preview-wrap';
        wrap.innerHTML = '<div id="dqrc-preview-box" style="border:1px solid #ddd;padding:10px;display:inline-block"></div>' +
                         '<div style="margin-top:10px">' +
                         '<button type="button" id="dqrc-open" class="btn btn-default">In neuem Tab öffnen</button> ' +
                         '<button type="button" id="dqrc-download" class="btn btn-default">SVG herunterladen</button>' +
                         '</div>' +
                         '<div style="margin-top:10px"><input type="text" id="dqrc-url" class="form-control" readonly onclick="this.select()"></div>';
        previewContainer.appendChild(wrap);

        const recordUid = TYPO3.settings.FormEngine.recordUid;
        if (!recordUid) return;

        // HMAC bauen per Ajax-Aufruf an Middleware (vereinfachend hier nur UID anzeigen)
        const baseUrl = TYPO3.settings.ajaxUrls ? window.location.origin : window.location.origin;
        const url = window.location.origin + '/dynamic-qrcode/svg?uid=' + recordUid;
        document.getElementById('dqrc-url').value = url;
        document.getElementById('dqrc-open').onclick = () => window.open(url, '_blank');
        document.getElementById('dqrc-download').onclick = () => { window.location.href = url + '&download=1'; };

        // Für Preview einfach ein <img> setzen (Browser rendert SVG direkt)
        const img = document.createElement('img');
        img.src = url;
        img.width = 300;
        img.height = 300;
        const box = document.getElementById('dqrc-preview-box');
        box.innerHTML = '';
        box.appendChild(img);
    });
})();